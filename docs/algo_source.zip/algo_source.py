'''
##############################################################
# Created Date: Thursday, April 24th 2025
# Contact Info: luoxiangyong01@gmail.com
# Author/Copyright: Mr. Xiangyong Luo
##############################################################
'''

from typing import Iterable
import math


def algo_quick_sort(array: Iterable, verbose: bool = False) -> Iterable:
    """Sort the input array using quick sort algorithm.

    Args:
        array (Iterable): iterable object to be sorted.
        verbose (bool, optional): Whether to print out running time. Defaults to False.

    Raises:
        ValueError: Input should be iterable.

    Returns:
        Iterable: sorted array

    Example:
        >>> from pyufunc import quick_sort
        >>> quick_sort([3, 6, 8, 10, 1, 2, 1])
        [1, 1, 2, 3, 6, 8, 10]
        >>> quick_sort([3, 6, 8, 10, 1, 2, 1], verbose=True)
        Running time of quick_sort: O(n log n)
        [1, 1, 2, 3, 6, 8, 10]
    """

    # TDD: Test-Driven Development
    # check if the input is iterable or not
    if not isinstance(array, Iterable):
        raise ValueError("Input should be iterable")

    if len(array) <= 1:
        return array

    pivot = array[len(array) // 2]
    left = [x for x in array if x < pivot]
    middle = [x for x in array if x == pivot]
    right = [x for x in array if x > pivot]

    if verbose:
        print("Running time of quick_sort: O(n log n)")

    return algo_quick_sort(left) + middle + algo_quick_sort(right)


def algo_merge_sort(array: Iterable, verbose: bool = False) -> Iterable:
    """Sort the input array using merge sort algorithm.

    Args:
        array (Iterable): iterable object to be sorted.
        verbose (bool, optional): whether to print out running time. Defaults to False.

    Raises:
        ValueError: Input should be iterable.

    Returns:
        Iterable: sorted array

    Example:
        >>> from pyufunc import merge_sort
        >>> merge_sort([3, 6, 8, 10, 1, 2, 1])
        [1, 1, 2, 3, 6, 8, 10]
        >>> merge_sort([3, 6, 8, 10, 1, 2, 1], verbose=True)
        Running time of merge_sort: O(n log n): 29.0
        [1, 1, 2, 3, 6, 8, 10]

    """

    # TDD: Test-Driven Development
    # check if the input is iterable or not
    if not isinstance(array, Iterable):
        raise ValueError("Input should be iterable")

    # check if the input array is larger than 1
    if len(array) <= 1:
        return array
